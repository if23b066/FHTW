<?php
$_ENV['DB_SERVER'] = 'localhost';
$_ENV['DB_USERNAME'] = 'bif2webscriptinguser';
$_ENV['DB_PASSWORD'] = 'bif2021';
$_ENV['DB_DATABASE'] = 'appointment_maker';