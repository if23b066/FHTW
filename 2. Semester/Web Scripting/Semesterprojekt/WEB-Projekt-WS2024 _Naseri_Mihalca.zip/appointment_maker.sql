-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 22. Apr 2024 um 18:56
-- Server-Version: 10.4.28-MariaDB
-- PHP-Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `appointment_maker`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `appointments`
--

CREATE TABLE `appointments` (
  `appointmentID` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `date` date NOT NULL,
  `expiry_date` date NOT NULL,
  `location` varchar(128) NOT NULL,
  `description` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `appointments`
--

INSERT INTO `appointments` (`appointmentID`, `title`, `date`, `expiry_date`, `location`, `description`) VALUES
(5, 'Zahnarzt', '2024-06-19', '2024-04-16', 'Höchstädtplatz 6', 'Dr Wolfgang Seemann'),
(6, 'Business Meeting', '2024-05-31', '2024-05-24', 'Reumannplatz 156', 'Elon Musk'),
(7, 'Geburtstag-Feier', '2024-07-16', '2024-05-30', 'Quellenplatz 4', 'Alle sind eingeladen!');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `options`
--

CREATE TABLE `options` (
  `optionsID` int(11) NOT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `comment` tinytext NOT NULL,
  `taken` tinyint(1) NOT NULL,
  `username` varchar(128) NOT NULL,
  `FK_appointmentID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Daten für Tabelle `options`
--

INSERT INTO `options` (`optionsID`, `startTime`, `endTime`, `comment`, `taken`, `username`, `FK_appointmentID`) VALUES
(9, '12:00:00', '13:50:00', '', 0, '', 5),
(10, '09:40:00', '11:30:00', '', 0, '', 5),
(11, '09:45:00', '10:35:00', 'Anzug waschen lassen', 1, 'Armin', 6),
(12, '10:50:00', '12:00:00', '', 0, '', 6),
(13, '19:45:00', '23:00:00', '', 0, '', 7),
(14, '18:00:00', '23:30:00', '', 0, '', 7);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointmentID`);

--
-- Indizes für die Tabelle `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`optionsID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT für Tabelle `options`
--
ALTER TABLE `options`
  MODIFY `optionsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
